-- Run with mysql --default-character-set=utf8mb4 < Database/MySQL/00_Create_Databases.sql
-- Existing databases are preserved. MySQL databases provide the namespace used as the kora schema in SQL Server and PostgreSQL.
CREATE DATABASE IF NOT EXISTS KoraOperations CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE DATABASE IF NOT EXISTS KoraPeople CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
