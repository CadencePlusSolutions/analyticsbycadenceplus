-- Connect to KoraOperations before running the following checks.
\connect KoraOperations
DO $$ BEGIN
 IF (SELECT COUNT(*) FROM kora."dataset_info") <> 1 THEN RAISE EXCEPTION 'KoraOperations.dataset_info row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."months") <> 48 THEN RAISE EXCEPTION 'KoraOperations.months row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."branches") <> 6 THEN RAISE EXCEPTION 'KoraOperations.branches row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."customers") <> 800 THEN RAISE EXCEPTION 'KoraOperations.customers row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."products") <> 36 THEN RAISE EXCEPTION 'KoraOperations.products row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."orders") <> 27999 THEN RAISE EXCEPTION 'KoraOperations.orders row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."order_lines") <> 56009 THEN RAISE EXCEPTION 'KoraOperations.order_lines row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."deliveries") <> 30357 THEN RAISE EXCEPTION 'KoraOperations.deliveries row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."delivery_lines") <> 60366 THEN RAISE EXCEPTION 'KoraOperations.delivery_lines row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."sales_lines") <> 60366 THEN RAISE EXCEPTION 'KoraOperations.sales_lines row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."returns") <> 2310 THEN RAISE EXCEPTION 'KoraOperations.returns row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."inventory_movements") <> 71208 THEN RAISE EXCEPTION 'KoraOperations.inventory_movements row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."inventory_monthly_snapshot") <> 10368 THEN RAISE EXCEPTION 'KoraOperations.inventory_monthly_snapshot row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."open_order_monthly_snapshot") <> 12520 THEN RAISE EXCEPTION 'KoraOperations.open_order_monthly_snapshot row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."branch_monthly_resources") <> 288 THEN RAISE EXCEPTION 'KoraOperations.branch_monthly_resources row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."payment_terms") <> 3 THEN RAISE EXCEPTION 'KoraOperations.payment_terms row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."invoices") <> 30194 THEN RAISE EXCEPTION 'KoraOperations.invoices row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."credit_notes") <> 2310 THEN RAISE EXCEPTION 'KoraOperations.credit_notes row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."cash_receipts") <> 29019 THEN RAISE EXCEPTION 'KoraOperations.cash_receipts row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."payment_allocations") <> 29622 THEN RAISE EXCEPTION 'KoraOperations.payment_allocations row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."cash_refunds") <> 437 THEN RAISE EXCEPTION 'KoraOperations.cash_refunds row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."operating_expenses") <> 31509 THEN RAISE EXCEPTION 'KoraOperations.operating_expenses row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."monthly_budgets") <> 288 THEN RAISE EXCEPTION 'KoraOperations.monthly_budgets row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."receivables_monthly_snapshot") <> 120995 THEN RAISE EXCEPTION 'KoraOperations.receivables_monthly_snapshot row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."suppliers") <> 6 THEN RAISE EXCEPTION 'KoraOperations.suppliers row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."purchase_orders") <> 7947 THEN RAISE EXCEPTION 'KoraOperations.purchase_orders row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."purchase_order_lines") <> 7947 THEN RAISE EXCEPTION 'KoraOperations.purchase_order_lines row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."goods_receipts") <> 8938 THEN RAISE EXCEPTION 'KoraOperations.goods_receipts row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."stock_shortage_events") <> 3816 THEN RAISE EXCEPTION 'KoraOperations.stock_shortage_events row count mismatch'; END IF;
END $$;
SELECT 'KoraOperations: row counts passed' AS result;

-- Connect to KoraPeople before running the following checks.
\connect KoraPeople
DO $$ BEGIN
 IF (SELECT COUNT(*) FROM kora."dataset_info") <> 1 THEN RAISE EXCEPTION 'KoraPeople.dataset_info row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."months") <> 48 THEN RAISE EXCEPTION 'KoraPeople.months row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."branches") <> 6 THEN RAISE EXCEPTION 'KoraPeople.branches row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."employees") <> 372 THEN RAISE EXCEPTION 'KoraPeople.employees row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."employment_spells") <> 383 THEN RAISE EXCEPTION 'KoraPeople.employment_spells row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."assignments") <> 1357 THEN RAISE EXCEPTION 'KoraPeople.assignments row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."staff_monthly_snapshot") <> 11112 THEN RAISE EXCEPTION 'KoraPeople.staff_monthly_snapshot row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."staff_monthly_hours") <> 11227 THEN RAISE EXCEPTION 'KoraPeople.staff_monthly_hours row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."promotion_rounds") <> 18 THEN RAISE EXCEPTION 'KoraPeople.promotion_rounds row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."promotion_candidates") <> 500 THEN RAISE EXCEPTION 'KoraPeople.promotion_candidates row count mismatch'; END IF;
 IF (SELECT COUNT(*) FROM kora."grades") <> 6 THEN RAISE EXCEPTION 'KoraPeople.grades row count mismatch'; END IF;
END $$;
SELECT 'KoraPeople: row counts passed' AS result;
