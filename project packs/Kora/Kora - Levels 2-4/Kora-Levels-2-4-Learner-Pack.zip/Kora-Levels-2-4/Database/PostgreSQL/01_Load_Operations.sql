-- KoraOperations: run from the extracted Kora-Levels-2-4 folder with psql -X -v ON_ERROR_STOP=1 -d KoraOperations -f Database/PostgreSQL/01_Load_Operations.sql
-- Client-side \copy reads the supplied CSVs. The script refuses to overwrite any existing kora tables.
BEGIN;
CREATE SCHEMA IF NOT EXISTS kora;
DO $$ BEGIN IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='kora' AND table_type='BASE TABLE') THEN RAISE EXCEPTION 'kora tables already exist; load into a fresh database'; END IF; END $$;
CREATE TABLE kora."dataset_info" (
  "dataset_version" varchar(30) NOT NULL,
  "start_date" date NOT NULL,
  "cutoff_date" date NOT NULL,
  "currency" varchar(3) NOT NULL,
  PRIMARY KEY ("dataset_version")
);

\copy kora."dataset_info" ("dataset_version", "start_date", "cutoff_date", "currency") FROM 'Data/KoraOperations/dataset_info.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."months" (
  "snapshot_date" date NOT NULL,
  "month_start" date NOT NULL,
  "calendar_year" integer NOT NULL,
  "month_number" integer NOT NULL,
  PRIMARY KEY ("snapshot_date")
);

\copy kora."months" ("snapshot_date", "month_start", "calendar_year", "month_number") FROM 'Data/KoraOperations/months.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."branches" (
  "branch_id" varchar(8) NOT NULL,
  "branch_name" varchar(80) NOT NULL,
  "region_name" varchar(40) NOT NULL,
  "city" varchar(40) NOT NULL,
  PRIMARY KEY ("branch_id")
);

\copy kora."branches" ("branch_id", "branch_name", "region_name", "city") FROM 'Data/KoraOperations/branches.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."customers" (
  "customer_id" varchar(12) NOT NULL,
  "customer_name" varchar(80) NOT NULL,
  "region_name" varchar(40) NOT NULL,
  "segment" varchar(30) NOT NULL,
  PRIMARY KEY ("customer_id")
);

\copy kora."customers" ("customer_id", "customer_name", "region_name", "segment") FROM 'Data/KoraOperations/customers.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."products" (
  "product_id" varchar(12) NOT NULL,
  "product_name" varchar(80) NOT NULL,
  "category" varchar(30) NOT NULL,
  "standard_unit_cost_ngn" numeric(18,2) NOT NULL,
  PRIMARY KEY ("product_id")
);

\copy kora."products" ("product_id", "product_name", "category", "standard_unit_cost_ngn") FROM 'Data/KoraOperations/products.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."orders" (
  "order_id" integer NOT NULL,
  "customer_id" varchar(12) NOT NULL,
  "branch_id" varchar(8) NOT NULL,
  "order_date" date NOT NULL,
  "promised_date" date NOT NULL,
  "cancelled_date" date NULL,
  "channel" varchar(20) NOT NULL,
  "complexity" varchar(20) NOT NULL,
  "standard_work_hours" numeric(10,2) NOT NULL,
  PRIMARY KEY ("order_id"),
  FOREIGN KEY ("customer_id") REFERENCES kora."customers" ("customer_id"),
  FOREIGN KEY ("branch_id") REFERENCES kora."branches" ("branch_id"),
  CHECK (promised_date >= order_date),
  CHECK (cancelled_date IS NULL OR cancelled_date >= order_date)
);

\copy kora."orders" ("order_id", "customer_id", "branch_id", "order_date", "promised_date", "cancelled_date", "channel", "complexity", "standard_work_hours") FROM 'Data/KoraOperations/orders.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."order_lines" (
  "order_line_id" integer NOT NULL,
  "order_id" integer NOT NULL,
  "product_id" varchar(12) NOT NULL,
  "quantity" integer NOT NULL,
  "unit_price_ngn" numeric(18,2) NOT NULL,
  "discount_rate" numeric(5,4) NOT NULL,
  "net_order_value_ngn" numeric(18,2) NOT NULL,
  PRIMARY KEY ("order_line_id"),
  FOREIGN KEY ("order_id") REFERENCES kora."orders" ("order_id"),
  FOREIGN KEY ("product_id") REFERENCES kora."products" ("product_id"),
  CHECK (quantity > 0),
  CHECK (discount_rate >= 0 AND discount_rate <= 1)
);

\copy kora."order_lines" ("order_line_id", "order_id", "product_id", "quantity", "unit_price_ngn", "discount_rate", "net_order_value_ngn") FROM 'Data/KoraOperations/order_lines.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."deliveries" (
  "delivery_id" integer NOT NULL,
  "order_id" integer NOT NULL,
  "promised_date" date NOT NULL,
  "delivery_date" date NULL,
  "status" varchar(20) NOT NULL,
  "shipping_cost_ngn" numeric(18,2) NOT NULL,
  "rework_hours" numeric(10,2) NOT NULL,
  "complaint_flag" boolean NOT NULL,
  PRIMARY KEY ("delivery_id"),
  FOREIGN KEY ("order_id") REFERENCES kora."orders" ("order_id")
);

\copy kora."deliveries" ("delivery_id", "order_id", "promised_date", "delivery_date", "status", "shipping_cost_ngn", "rework_hours", "complaint_flag") FROM 'Data/KoraOperations/deliveries.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."delivery_lines" (
  "delivery_id" integer NOT NULL,
  "order_line_id" integer NOT NULL,
  "delivered_quantity" integer NOT NULL,
  PRIMARY KEY ("delivery_id", "order_line_id"),
  FOREIGN KEY ("delivery_id") REFERENCES kora."deliveries" ("delivery_id"),
  FOREIGN KEY ("order_line_id") REFERENCES kora."order_lines" ("order_line_id"),
  CHECK (delivered_quantity > 0)
);

\copy kora."delivery_lines" ("delivery_id", "order_line_id", "delivered_quantity") FROM 'Data/KoraOperations/delivery_lines.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."sales_lines" (
  "sales_line_id" integer NOT NULL,
  "delivery_id" integer NOT NULL,
  "order_line_id" integer NOT NULL,
  "sale_date" date NOT NULL,
  "quantity" integer NOT NULL,
  "sales_value_ngn" numeric(18,2) NOT NULL,
  "cost_of_goods_ngn" numeric(18,2) NOT NULL,
  PRIMARY KEY ("sales_line_id"),
  FOREIGN KEY ("delivery_id") REFERENCES kora."deliveries" ("delivery_id"),
  FOREIGN KEY ("order_line_id") REFERENCES kora."order_lines" ("order_line_id")
);

\copy kora."sales_lines" ("sales_line_id", "delivery_id", "order_line_id", "sale_date", "quantity", "sales_value_ngn", "cost_of_goods_ngn") FROM 'Data/KoraOperations/sales_lines.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."returns" (
  "return_id" integer NOT NULL,
  "sales_line_id" integer NOT NULL,
  "return_date" date NOT NULL,
  "quantity" integer NOT NULL,
  "refund_ngn" numeric(18,2) NOT NULL,
  "recovered_cost_ngn" numeric(18,2) NOT NULL,
  "restocked" boolean NOT NULL,
  "return_reason" varchar(40) NULL,
  PRIMARY KEY ("return_id"),
  FOREIGN KEY ("sales_line_id") REFERENCES kora."sales_lines" ("sales_line_id")
);

\copy kora."returns" ("return_id", "sales_line_id", "return_date", "quantity", "refund_ngn", "recovered_cost_ngn", "restocked", "return_reason") FROM 'Data/KoraOperations/returns.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."inventory_movements" (
  "movement_id" integer NOT NULL,
  "branch_id" varchar(8) NOT NULL,
  "product_id" varchar(12) NOT NULL,
  "movement_date" date NOT NULL,
  "movement_type" varchar(20) NOT NULL,
  "quantity_change" integer NOT NULL,
  "sales_line_id" integer NULL,
  "return_id" integer NULL,
  PRIMARY KEY ("movement_id"),
  FOREIGN KEY ("branch_id") REFERENCES kora."branches" ("branch_id"),
  FOREIGN KEY ("product_id") REFERENCES kora."products" ("product_id"),
  FOREIGN KEY ("sales_line_id") REFERENCES kora."sales_lines" ("sales_line_id"),
  FOREIGN KEY ("return_id") REFERENCES kora."returns" ("return_id")
);

\copy kora."inventory_movements" ("movement_id", "branch_id", "product_id", "movement_date", "movement_type", "quantity_change", "sales_line_id", "return_id") FROM 'Data/KoraOperations/inventory_movements.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."inventory_monthly_snapshot" (
  "snapshot_date" date NOT NULL,
  "branch_id" varchar(8) NOT NULL,
  "product_id" varchar(12) NOT NULL,
  "on_hand_quantity" integer NOT NULL,
  "stock_value_ngn" numeric(18,2) NOT NULL,
  PRIMARY KEY ("snapshot_date", "branch_id", "product_id"),
  FOREIGN KEY ("snapshot_date") REFERENCES kora."months" ("snapshot_date"),
  FOREIGN KEY ("branch_id") REFERENCES kora."branches" ("branch_id"),
  FOREIGN KEY ("product_id") REFERENCES kora."products" ("product_id")
);

\copy kora."inventory_monthly_snapshot" ("snapshot_date", "branch_id", "product_id", "on_hand_quantity", "stock_value_ngn") FROM 'Data/KoraOperations/inventory_monthly_snapshot.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."open_order_monthly_snapshot" (
  "snapshot_date" date NOT NULL,
  "order_line_id" integer NOT NULL,
  "open_quantity" integer NOT NULL,
  "open_value_ngn" numeric(18,2) NOT NULL,
  PRIMARY KEY ("snapshot_date", "order_line_id"),
  FOREIGN KEY ("snapshot_date") REFERENCES kora."months" ("snapshot_date"),
  FOREIGN KEY ("order_line_id") REFERENCES kora."order_lines" ("order_line_id")
);

\copy kora."open_order_monthly_snapshot" ("snapshot_date", "order_line_id", "open_quantity", "open_value_ngn") FROM 'Data/KoraOperations/open_order_monthly_snapshot.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."branch_monthly_resources" (
  "snapshot_date" date NOT NULL,
  "branch_id" varchar(8) NOT NULL,
  "available_service_hours" numeric(12,2) NOT NULL,
  "fixed_operating_cost_ngn" numeric(18,2) NOT NULL,
  "overtime_cost_ngn" numeric(18,2) NOT NULL,
  "service_budget_ngn" numeric(18,2) NOT NULL,
  PRIMARY KEY ("snapshot_date", "branch_id"),
  FOREIGN KEY ("snapshot_date") REFERENCES kora."months" ("snapshot_date"),
  FOREIGN KEY ("branch_id") REFERENCES kora."branches" ("branch_id")
);

\copy kora."branch_monthly_resources" ("snapshot_date", "branch_id", "available_service_hours", "fixed_operating_cost_ngn", "overtime_cost_ngn", "service_budget_ngn") FROM 'Data/KoraOperations/branch_monthly_resources.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."payment_terms" (
  "payment_term_id" varchar(10) NOT NULL,
  "term_days" integer NOT NULL,
  "description" varchar(100) NOT NULL,
  PRIMARY KEY ("payment_term_id")
);

\copy kora."payment_terms" ("payment_term_id", "term_days", "description") FROM 'Data/KoraOperations/payment_terms.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."invoices" (
  "invoice_id" integer NOT NULL,
  "delivery_id" integer NOT NULL,
  "customer_id" varchar(12) NOT NULL,
  "branch_id" varchar(8) NOT NULL,
  "invoice_date" date NOT NULL,
  "due_date" date NOT NULL,
  "payment_term_id" varchar(10) NOT NULL,
  "invoice_amount_ngn" numeric(18,2) NOT NULL,
  PRIMARY KEY ("invoice_id"),
  FOREIGN KEY ("delivery_id") REFERENCES kora."deliveries" ("delivery_id"),
  FOREIGN KEY ("customer_id") REFERENCES kora."customers" ("customer_id"),
  FOREIGN KEY ("branch_id") REFERENCES kora."branches" ("branch_id"),
  FOREIGN KEY ("payment_term_id") REFERENCES kora."payment_terms" ("payment_term_id"),
  CHECK (due_date >= invoice_date),
  CHECK (invoice_amount_ngn > 0)
);

\copy kora."invoices" ("invoice_id", "delivery_id", "customer_id", "branch_id", "invoice_date", "due_date", "payment_term_id", "invoice_amount_ngn") FROM 'Data/KoraOperations/invoices.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."credit_notes" (
  "credit_note_id" integer NOT NULL,
  "invoice_id" integer NOT NULL,
  "return_id" integer NOT NULL,
  "credit_date" date NOT NULL,
  "credit_amount_ngn" numeric(18,2) NOT NULL,
  PRIMARY KEY ("credit_note_id"),
  FOREIGN KEY ("invoice_id") REFERENCES kora."invoices" ("invoice_id"),
  FOREIGN KEY ("return_id") REFERENCES kora."returns" ("return_id"),
  CHECK (credit_amount_ngn > 0)
);

\copy kora."credit_notes" ("credit_note_id", "invoice_id", "return_id", "credit_date", "credit_amount_ngn") FROM 'Data/KoraOperations/credit_notes.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."cash_receipts" (
  "receipt_id" integer NOT NULL,
  "customer_id" varchar(12) NOT NULL,
  "receipt_date" date NOT NULL,
  "amount_ngn" numeric(18,2) NOT NULL,
  PRIMARY KEY ("receipt_id"),
  FOREIGN KEY ("customer_id") REFERENCES kora."customers" ("customer_id"),
  CHECK (amount_ngn > 0)
);

\copy kora."cash_receipts" ("receipt_id", "customer_id", "receipt_date", "amount_ngn") FROM 'Data/KoraOperations/cash_receipts.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."payment_allocations" (
  "allocation_id" integer NOT NULL,
  "receipt_id" integer NOT NULL,
  "invoice_id" integer NOT NULL,
  "allocated_amount_ngn" numeric(18,2) NOT NULL,
  PRIMARY KEY ("allocation_id"),
  FOREIGN KEY ("receipt_id") REFERENCES kora."cash_receipts" ("receipt_id"),
  FOREIGN KEY ("invoice_id") REFERENCES kora."invoices" ("invoice_id"),
  CHECK (allocated_amount_ngn > 0)
);

\copy kora."payment_allocations" ("allocation_id", "receipt_id", "invoice_id", "allocated_amount_ngn") FROM 'Data/KoraOperations/payment_allocations.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."cash_refunds" (
  "cash_refund_id" integer NOT NULL,
  "credit_note_id" integer NOT NULL,
  "refund_date" date NOT NULL,
  "amount_ngn" numeric(18,2) NOT NULL,
  PRIMARY KEY ("cash_refund_id"),
  FOREIGN KEY ("credit_note_id") REFERENCES kora."credit_notes" ("credit_note_id"),
  CHECK (amount_ngn > 0)
);

\copy kora."cash_refunds" ("cash_refund_id", "credit_note_id", "refund_date", "amount_ngn") FROM 'Data/KoraOperations/cash_refunds.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."operating_expenses" (
  "expense_id" integer NOT NULL,
  "branch_id" varchar(8) NOT NULL,
  "recognition_date" date NOT NULL,
  "expense_category" varchar(40) NOT NULL,
  "amount_ngn" numeric(18,2) NOT NULL,
  "delivery_id" integer NULL,
  PRIMARY KEY ("expense_id"),
  FOREIGN KEY ("branch_id") REFERENCES kora."branches" ("branch_id"),
  FOREIGN KEY ("delivery_id") REFERENCES kora."deliveries" ("delivery_id"),
  CHECK (amount_ngn >= 0)
);

\copy kora."operating_expenses" ("expense_id", "branch_id", "recognition_date", "expense_category", "amount_ngn", "delivery_id") FROM 'Data/KoraOperations/operating_expenses.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."monthly_budgets" (
  "snapshot_date" date NOT NULL,
  "branch_id" varchar(8) NOT NULL,
  "approved_date" date NOT NULL,
  "budget_net_sales_ngn" numeric(18,2) NOT NULL,
  "budget_net_cogs_ngn" numeric(18,2) NOT NULL,
  "budget_operating_expenses_ngn" numeric(18,2) NOT NULL,
  PRIMARY KEY ("snapshot_date", "branch_id"),
  FOREIGN KEY ("snapshot_date") REFERENCES kora."months" ("snapshot_date"),
  FOREIGN KEY ("branch_id") REFERENCES kora."branches" ("branch_id")
);

\copy kora."monthly_budgets" ("snapshot_date", "branch_id", "approved_date", "budget_net_sales_ngn", "budget_net_cogs_ngn", "budget_operating_expenses_ngn") FROM 'Data/KoraOperations/monthly_budgets.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."receivables_monthly_snapshot" (
  "snapshot_date" date NOT NULL,
  "invoice_id" integer NOT NULL,
  "balance_ngn" numeric(18,2) NOT NULL,
  "days_past_due" integer NOT NULL,
  PRIMARY KEY ("snapshot_date", "invoice_id"),
  FOREIGN KEY ("snapshot_date") REFERENCES kora."months" ("snapshot_date"),
  FOREIGN KEY ("invoice_id") REFERENCES kora."invoices" ("invoice_id")
);

\copy kora."receivables_monthly_snapshot" ("snapshot_date", "invoice_id", "balance_ngn", "days_past_due") FROM 'Data/KoraOperations/receivables_monthly_snapshot.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."suppliers" (
  "supplier_id" varchar(8) NOT NULL,
  "supplier_name" varchar(80) NOT NULL,
  "standard_lead_days" integer NOT NULL,
  PRIMARY KEY ("supplier_id")
);

\copy kora."suppliers" ("supplier_id", "supplier_name", "standard_lead_days") FROM 'Data/KoraOperations/suppliers.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."purchase_orders" (
  "purchase_order_id" integer NOT NULL,
  "supplier_id" varchar(8) NOT NULL,
  "branch_id" varchar(8) NOT NULL,
  "ordered_date" date NOT NULL,
  "promised_receipt_date" date NOT NULL,
  "order_type" varchar(20) NOT NULL,
  PRIMARY KEY ("purchase_order_id"),
  FOREIGN KEY ("supplier_id") REFERENCES kora."suppliers" ("supplier_id"),
  FOREIGN KEY ("branch_id") REFERENCES kora."branches" ("branch_id")
);

\copy kora."purchase_orders" ("purchase_order_id", "supplier_id", "branch_id", "ordered_date", "promised_receipt_date", "order_type") FROM 'Data/KoraOperations/purchase_orders.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."purchase_order_lines" (
  "purchase_order_line_id" integer NOT NULL,
  "purchase_order_id" integer NOT NULL,
  "product_id" varchar(12) NOT NULL,
  "ordered_quantity" integer NOT NULL,
  "unit_cost_ngn" numeric(18,2) NOT NULL,
  PRIMARY KEY ("purchase_order_line_id"),
  FOREIGN KEY ("purchase_order_id") REFERENCES kora."purchase_orders" ("purchase_order_id"),
  FOREIGN KEY ("product_id") REFERENCES kora."products" ("product_id")
);

\copy kora."purchase_order_lines" ("purchase_order_line_id", "purchase_order_id", "product_id", "ordered_quantity", "unit_cost_ngn") FROM 'Data/KoraOperations/purchase_order_lines.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."goods_receipts" (
  "goods_receipt_id" integer NOT NULL,
  "purchase_order_line_id" integer NOT NULL,
  "movement_id" integer NOT NULL,
  "received_date" date NOT NULL,
  "received_quantity" integer NOT NULL,
  PRIMARY KEY ("goods_receipt_id"),
  FOREIGN KEY ("purchase_order_line_id") REFERENCES kora."purchase_order_lines" ("purchase_order_line_id"),
  FOREIGN KEY ("movement_id") REFERENCES kora."inventory_movements" ("movement_id")
);

\copy kora."goods_receipts" ("goods_receipt_id", "purchase_order_line_id", "movement_id", "received_date", "received_quantity") FROM 'Data/KoraOperations/goods_receipts.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."stock_shortage_events" (
  "shortage_id" integer NOT NULL,
  "sales_line_id" integer NOT NULL,
  "branch_id" varchar(8) NOT NULL,
  "product_id" varchar(12) NOT NULL,
  "event_date" date NOT NULL,
  "required_quantity" integer NOT NULL,
  "available_quantity" integer NOT NULL,
  "shortage_quantity" integer NOT NULL,
  "emergency_purchase_order_id" integer NOT NULL,
  PRIMARY KEY ("shortage_id"),
  FOREIGN KEY ("sales_line_id") REFERENCES kora."sales_lines" ("sales_line_id"),
  FOREIGN KEY ("branch_id") REFERENCES kora."branches" ("branch_id"),
  FOREIGN KEY ("product_id") REFERENCES kora."products" ("product_id"),
  FOREIGN KEY ("emergency_purchase_order_id") REFERENCES kora."purchase_orders" ("purchase_order_id")
);

\copy kora."stock_shortage_events" ("shortage_id", "sales_line_id", "branch_id", "product_id", "event_date", "required_quantity", "available_quantity", "shortage_quantity", "emergency_purchase_order_id") FROM 'Data/KoraOperations/stock_shortage_events.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
COMMIT;
