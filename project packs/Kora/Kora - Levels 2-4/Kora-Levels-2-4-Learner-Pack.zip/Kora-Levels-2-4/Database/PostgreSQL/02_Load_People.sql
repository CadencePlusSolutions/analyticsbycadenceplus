-- KoraPeople: run from the extracted Kora-Levels-2-4 folder with psql -X -v ON_ERROR_STOP=1 -d KoraPeople -f Database/PostgreSQL/02_Load_People.sql
-- Client-side \copy reads the supplied CSVs. The script refuses to overwrite any existing kora tables.
BEGIN;
CREATE SCHEMA IF NOT EXISTS kora;
DO $$ BEGIN IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='kora' AND table_type='BASE TABLE') THEN RAISE EXCEPTION 'kora tables already exist; load into a fresh database'; END IF; END $$;
CREATE TABLE kora."dataset_info" (
  "dataset_version" varchar(30) NOT NULL,
  "start_date" date NOT NULL,
  "cutoff_date" date NOT NULL,
  "currency" varchar(3) NOT NULL,
  PRIMARY KEY ("dataset_version")
);

\copy kora."dataset_info" ("dataset_version", "start_date", "cutoff_date", "currency") FROM 'Data/KoraPeople/dataset_info.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."months" (
  "snapshot_date" date NOT NULL,
  "month_start" date NOT NULL,
  "calendar_year" integer NOT NULL,
  "month_number" integer NOT NULL,
  PRIMARY KEY ("snapshot_date")
);

\copy kora."months" ("snapshot_date", "month_start", "calendar_year", "month_number") FROM 'Data/KoraPeople/months.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."branches" (
  "branch_id" varchar(8) NOT NULL,
  "branch_name" varchar(80) NOT NULL,
  "region_name" varchar(40) NOT NULL,
  "city" varchar(40) NOT NULL,
  PRIMARY KEY ("branch_id")
);

\copy kora."branches" ("branch_id", "branch_name", "region_name", "city") FROM 'Data/KoraPeople/branches.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."employees" (
  "employee_id" varchar(12) NOT NULL,
  "employee_name" varchar(80) NOT NULL,
  "first_hire_date" date NOT NULL,
  PRIMARY KEY ("employee_id")
);

\copy kora."employees" ("employee_id", "employee_name", "first_hire_date") FROM 'Data/KoraPeople/employees.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."employment_spells" (
  "spell_id" integer NOT NULL,
  "employee_id" varchar(12) NOT NULL,
  "hire_date" date NOT NULL,
  "termination_date" date NULL,
  "exit_type" varchar(30) NULL,
  "exit_reason" varchar(100) NULL,
  PRIMARY KEY ("spell_id"),
  FOREIGN KEY ("employee_id") REFERENCES kora."employees" ("employee_id"),
  CHECK (termination_date IS NULL OR termination_date > hire_date)
);

\copy kora."employment_spells" ("spell_id", "employee_id", "hire_date", "termination_date", "exit_type", "exit_reason") FROM 'Data/KoraPeople/employment_spells.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."assignments" (
  "assignment_id" integer NOT NULL,
  "spell_id" integer NOT NULL,
  "branch_id" varchar(8) NOT NULL,
  "manager_employee_id" varchar(12) NULL,
  "role_name" varchar(50) NOT NULL,
  "grade" integer NOT NULL,
  "annual_salary_ngn" numeric(18,2) NOT NULL,
  "fte" numeric(5,2) NOT NULL,
  "effective_start" date NOT NULL,
  "effective_end" date NULL,
  "change_type" varchar(25) NOT NULL,
  PRIMARY KEY ("assignment_id"),
  FOREIGN KEY ("spell_id") REFERENCES kora."employment_spells" ("spell_id"),
  FOREIGN KEY ("branch_id") REFERENCES kora."branches" ("branch_id"),
  FOREIGN KEY ("manager_employee_id") REFERENCES kora."employees" ("employee_id"),
  CHECK (effective_end IS NULL OR effective_end > effective_start),
  CHECK (fte > 0 AND fte <= 1),
  CHECK (annual_salary_ngn > 0)
);

\copy kora."assignments" ("assignment_id", "spell_id", "branch_id", "manager_employee_id", "role_name", "grade", "annual_salary_ngn", "fte", "effective_start", "effective_end", "change_type") FROM 'Data/KoraPeople/assignments.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."staff_monthly_snapshot" (
  "snapshot_date" date NOT NULL,
  "employee_id" varchar(12) NOT NULL,
  "spell_id" integer NOT NULL,
  "assignment_id" integer NOT NULL,
  "branch_id" varchar(8) NOT NULL,
  "manager_employee_id" varchar(12) NULL,
  "role_name" varchar(50) NOT NULL,
  "grade" integer NOT NULL,
  "annual_salary_ngn" numeric(18,2) NOT NULL,
  "fte" numeric(5,2) NOT NULL,
  PRIMARY KEY ("snapshot_date", "employee_id"),
  FOREIGN KEY ("snapshot_date") REFERENCES kora."months" ("snapshot_date"),
  FOREIGN KEY ("employee_id") REFERENCES kora."employees" ("employee_id"),
  FOREIGN KEY ("spell_id") REFERENCES kora."employment_spells" ("spell_id"),
  FOREIGN KEY ("assignment_id") REFERENCES kora."assignments" ("assignment_id"),
  FOREIGN KEY ("branch_id") REFERENCES kora."branches" ("branch_id"),
  FOREIGN KEY ("manager_employee_id") REFERENCES kora."employees" ("employee_id")
);

\copy kora."staff_monthly_snapshot" ("snapshot_date", "employee_id", "spell_id", "assignment_id", "branch_id", "manager_employee_id", "role_name", "grade", "annual_salary_ngn", "fte") FROM 'Data/KoraPeople/staff_monthly_snapshot.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."staff_monthly_hours" (
  "snapshot_date" date NOT NULL,
  "assignment_id" integer NOT NULL,
  "scheduled_hours" numeric(12,2) NOT NULL,
  "absence_hours" numeric(12,2) NOT NULL,
  "overtime_hours" numeric(12,2) NOT NULL,
  PRIMARY KEY ("snapshot_date", "assignment_id"),
  FOREIGN KEY ("snapshot_date") REFERENCES kora."months" ("snapshot_date"),
  FOREIGN KEY ("assignment_id") REFERENCES kora."assignments" ("assignment_id"),
  CHECK (scheduled_hours >= absence_hours AND absence_hours >= 0),
  CHECK (overtime_hours >= 0)
);

\copy kora."staff_monthly_hours" ("snapshot_date", "assignment_id", "scheduled_hours", "absence_hours", "overtime_hours") FROM 'Data/KoraPeople/staff_monthly_hours.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."promotion_rounds" (
  "round_id" integer NOT NULL,
  "branch_id" varchar(8) NOT NULL,
  "decision_date" date NOT NULL,
  "effective_date" date NOT NULL,
  "target_grade" integer NOT NULL,
  "positions" integer NOT NULL,
  "eligibility_policy" varchar(200) NOT NULL,
  PRIMARY KEY ("round_id"),
  FOREIGN KEY ("branch_id") REFERENCES kora."branches" ("branch_id")
);

\copy kora."promotion_rounds" ("round_id", "branch_id", "decision_date", "effective_date", "target_grade", "positions", "eligibility_policy") FROM 'Data/KoraPeople/promotion_rounds.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."promotion_candidates" (
  "round_id" integer NOT NULL,
  "employee_id" varchar(12) NOT NULL,
  "assignment_id_at_assessment" integer NOT NULL,
  "eligible" boolean NOT NULL,
  "assessment_score" numeric(5,2) NULL,
  "selected" boolean NOT NULL,
  "decision_reason" varchar(100) NULL,
  PRIMARY KEY ("round_id", "employee_id"),
  FOREIGN KEY ("round_id") REFERENCES kora."promotion_rounds" ("round_id"),
  FOREIGN KEY ("employee_id") REFERENCES kora."employees" ("employee_id"),
  FOREIGN KEY ("assignment_id_at_assessment") REFERENCES kora."assignments" ("assignment_id")
);

\copy kora."promotion_candidates" ("round_id", "employee_id", "assignment_id_at_assessment", "eligible", "assessment_score", "selected", "decision_reason") FROM 'Data/KoraPeople/promotion_candidates.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
CREATE TABLE kora."grades" (
  "grade" integer NOT NULL,
  "grade_label" varchar(60) NOT NULL,
  "definition" varchar(200) NOT NULL,
  PRIMARY KEY ("grade")
);

\copy kora."grades" ("grade", "grade_label", "definition") FROM 'Data/KoraPeople/grades.csv' WITH (FORMAT csv, HEADER true, ENCODING 'UTF8');
COMMIT;
