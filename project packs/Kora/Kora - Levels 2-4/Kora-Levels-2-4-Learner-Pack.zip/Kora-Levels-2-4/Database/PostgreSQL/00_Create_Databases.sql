-- Run with psql -X -v ON_ERROR_STOP=1 -d postgres -f Database/PostgreSQL/00_Create_Databases.sql
-- Existing databases are preserved. Run from the pack root.
SELECT format('CREATE DATABASE %I', 'KoraOperations') WHERE NOT EXISTS (SELECT 1 FROM pg_database WHERE datname='KoraOperations') \gexec
SELECT format('CREATE DATABASE %I', 'KoraPeople') WHERE NOT EXISTS (SELECT 1 FROM pg_database WHERE datname='KoraPeople') \gexec
