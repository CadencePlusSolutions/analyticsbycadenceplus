-- Read-only validation. Any failed assertion stops execution with THROW.
SET NOCOUNT ON;
SET XACT_ABORT ON;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[dataset_info]) <> 1 THROW 51001, 'Row count mismatch: KoraOperations.dataset_info', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[months]) <> 48 THROW 51001, 'Row count mismatch: KoraOperations.months', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[branches]) <> 6 THROW 51001, 'Row count mismatch: KoraOperations.branches', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraPeople].kora.[dataset_info]) <> 1 THROW 51001, 'Row count mismatch: KoraPeople.dataset_info', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraPeople].kora.[months]) <> 48 THROW 51001, 'Row count mismatch: KoraPeople.months', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraPeople].kora.[branches]) <> 6 THROW 51001, 'Row count mismatch: KoraPeople.branches', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraPeople].kora.[employees]) <> 372 THROW 51001, 'Row count mismatch: KoraPeople.employees', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraPeople].kora.[employment_spells]) <> 383 THROW 51001, 'Row count mismatch: KoraPeople.employment_spells', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraPeople].kora.[assignments]) <> 1357 THROW 51001, 'Row count mismatch: KoraPeople.assignments', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraPeople].kora.[staff_monthly_snapshot]) <> 11112 THROW 51001, 'Row count mismatch: KoraPeople.staff_monthly_snapshot', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraPeople].kora.[staff_monthly_hours]) <> 11227 THROW 51001, 'Row count mismatch: KoraPeople.staff_monthly_hours', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraPeople].kora.[promotion_rounds]) <> 18 THROW 51001, 'Row count mismatch: KoraPeople.promotion_rounds', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraPeople].kora.[promotion_candidates]) <> 500 THROW 51001, 'Row count mismatch: KoraPeople.promotion_candidates', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[customers]) <> 800 THROW 51001, 'Row count mismatch: KoraOperations.customers', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[products]) <> 36 THROW 51001, 'Row count mismatch: KoraOperations.products', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[orders]) <> 27999 THROW 51001, 'Row count mismatch: KoraOperations.orders', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[order_lines]) <> 56009 THROW 51001, 'Row count mismatch: KoraOperations.order_lines', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[deliveries]) <> 30357 THROW 51001, 'Row count mismatch: KoraOperations.deliveries', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[delivery_lines]) <> 60366 THROW 51001, 'Row count mismatch: KoraOperations.delivery_lines', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[sales_lines]) <> 60366 THROW 51001, 'Row count mismatch: KoraOperations.sales_lines', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[returns]) <> 2310 THROW 51001, 'Row count mismatch: KoraOperations.returns', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[inventory_movements]) <> 71208 THROW 51001, 'Row count mismatch: KoraOperations.inventory_movements', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[inventory_monthly_snapshot]) <> 10368 THROW 51001, 'Row count mismatch: KoraOperations.inventory_monthly_snapshot', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[open_order_monthly_snapshot]) <> 12520 THROW 51001, 'Row count mismatch: KoraOperations.open_order_monthly_snapshot', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[branch_monthly_resources]) <> 288 THROW 51001, 'Row count mismatch: KoraOperations.branch_monthly_resources', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraPeople].kora.[grades]) <> 6 THROW 51001, 'Row count mismatch: KoraPeople.grades', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[payment_terms]) <> 3 THROW 51001, 'Row count mismatch: KoraOperations.payment_terms', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[invoices]) <> 30194 THROW 51001, 'Row count mismatch: KoraOperations.invoices', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[credit_notes]) <> 2310 THROW 51001, 'Row count mismatch: KoraOperations.credit_notes', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[cash_receipts]) <> 29019 THROW 51001, 'Row count mismatch: KoraOperations.cash_receipts', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[payment_allocations]) <> 29622 THROW 51001, 'Row count mismatch: KoraOperations.payment_allocations', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[cash_refunds]) <> 437 THROW 51001, 'Row count mismatch: KoraOperations.cash_refunds', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[operating_expenses]) <> 31509 THROW 51001, 'Row count mismatch: KoraOperations.operating_expenses', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[monthly_budgets]) <> 288 THROW 51001, 'Row count mismatch: KoraOperations.monthly_budgets', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[receivables_monthly_snapshot]) <> 120995 THROW 51001, 'Row count mismatch: KoraOperations.receivables_monthly_snapshot', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[suppliers]) <> 6 THROW 51001, 'Row count mismatch: KoraOperations.suppliers', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[purchase_orders]) <> 7947 THROW 51001, 'Row count mismatch: KoraOperations.purchase_orders', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[purchase_order_lines]) <> 7947 THROW 51001, 'Row count mismatch: KoraOperations.purchase_order_lines', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[goods_receipts]) <> 8938 THROW 51001, 'Row count mismatch: KoraOperations.goods_receipts', 1;
IF (SELECT COUNT_BIG(*) FROM [KoraOperations].kora.[stock_shortage_events]) <> 3816 THROW 51001, 'Row count mismatch: KoraOperations.stock_shortage_events', 1;

IF (SELECT SUM(net_order_value_ngn) FROM KoraOperations.kora.order_lines) <> 28462239676.25 THROW 51002, 'Order value mismatch', 1;
IF (SELECT SUM(sales_value_ngn) FROM KoraOperations.kora.sales_lines) <> 26731304805.00 THROW 51002, 'Sales value mismatch', 1;
IF (SELECT SUM(refund_ngn) FROM KoraOperations.kora.returns) <> 547343982.50 THROW 51002, 'Refund mismatch', 1;
IF EXISTS (SELECT branch_id,branch_name,region_name,city FROM KoraOperations.kora.branches EXCEPT SELECT branch_id,branch_name,region_name,city FROM KoraPeople.kora.branches)
 OR EXISTS (SELECT branch_id,branch_name,region_name,city FROM KoraPeople.kora.branches EXCEPT SELECT branch_id,branch_name,region_name,city FROM KoraOperations.kora.branches)
 THROW 51003, 'Cross-database branch mismatch', 1;
IF EXISTS (SELECT 1 FROM KoraPeople.kora.assignments a JOIN KoraPeople.kora.assignments b ON a.spell_id=b.spell_id AND a.assignment_id<b.assignment_id
 WHERE a.effective_start<COALESCE(b.effective_end,'20260101') AND b.effective_start<COALESCE(a.effective_end,'20260101')) THROW 51004, 'Overlapping assignments', 1;
IF EXISTS (SELECT 1 FROM KoraPeople.kora.assignments a JOIN KoraPeople.kora.employment_spells s ON a.spell_id=s.spell_id WHERE a.effective_start<s.hire_date OR COALESCE(a.effective_end,'20260101')>COALESCE(s.termination_date,'20260101')) THROW 51004, 'Assignment outside employment spell', 1;
IF EXISTS (SELECT 1 FROM KoraPeople.kora.staff_monthly_snapshot x JOIN KoraPeople.kora.assignments a ON x.assignment_id=a.assignment_id WHERE x.snapshot_date<a.effective_start OR x.snapshot_date>=COALESCE(a.effective_end,'20260101') OR x.branch_id<>a.branch_id OR x.grade<>a.grade OR x.annual_salary_ngn<>a.annual_salary_ngn) THROW 51005, 'Staff snapshot disagrees with assignment', 1;
IF EXISTS (SELECT m.snapshot_date,s.employee_id FROM KoraPeople.kora.months m JOIN KoraPeople.kora.employment_spells s ON s.hire_date<=m.snapshot_date AND (s.termination_date IS NULL OR s.termination_date>m.snapshot_date)
 EXCEPT SELECT snapshot_date,employee_id FROM KoraPeople.kora.staff_monthly_snapshot) THROW 51005, 'Missing active staff snapshot', 1;
IF EXISTS (SELECT snapshot_date,employee_id FROM KoraPeople.kora.staff_monthly_snapshot EXCEPT SELECT m.snapshot_date,s.employee_id FROM KoraPeople.kora.months m JOIN KoraPeople.kora.employment_spells s ON s.hire_date<=m.snapshot_date AND (s.termination_date IS NULL OR s.termination_date>m.snapshot_date)) THROW 51005, 'Extra staff snapshot', 1;
IF EXISTS (SELECT 1 FROM KoraOperations.kora.order_lines l JOIN (SELECT order_line_id,SUM(quantity) q FROM KoraOperations.kora.sales_lines GROUP BY order_line_id) s ON l.order_line_id=s.order_line_id WHERE s.q>l.quantity) THROW 51006, 'Overfulfilled order line', 1;
IF EXISTS (SELECT 1 FROM KoraOperations.kora.sales_lines s JOIN KoraOperations.kora.order_lines l ON s.order_line_id=l.order_line_id JOIN KoraOperations.kora.orders o ON l.order_id=o.order_id WHERE o.cancelled_date IS NOT NULL OR s.sale_date<o.order_date OR s.sale_date>'20251231') THROW 51006, 'Invalid sale timing or cancelled sale', 1;
IF EXISTS (SELECT 1 FROM KoraOperations.kora.returns r JOIN KoraOperations.kora.sales_lines s ON r.sales_line_id=s.sales_line_id WHERE r.return_date<s.sale_date OR r.quantity>s.quantity OR r.return_date>'20251231') THROW 51006, 'Invalid return', 1;
IF EXISTS (SELECT 1 FROM KoraOperations.kora.inventory_monthly_snapshot s OUTER APPLY (SELECT SUM(m.quantity_change) q FROM KoraOperations.kora.inventory_movements m WHERE m.branch_id=s.branch_id AND m.product_id=s.product_id AND m.movement_date<=s.snapshot_date) v WHERE s.on_hand_quantity<>COALESCE(v.q,0) OR s.on_hand_quantity<0) THROW 51007, 'Inventory reconciliation failed', 1;
IF EXISTS (SELECT 1 FROM KoraOperations.kora.branch_monthly_resources r OUTER APPLY (SELECT SUM(h.scheduled_hours-h.absence_hours+h.overtime_hours) hrs FROM KoraPeople.kora.staff_monthly_hours h JOIN KoraPeople.kora.assignments a ON h.assignment_id=a.assignment_id WHERE h.snapshot_date=r.snapshot_date AND a.branch_id=r.branch_id AND a.role_name<>'Branch Manager') c WHERE ABS(r.available_service_hours-COALESCE(c.hrs,0))>0.01) THROW 51008, 'Service capacity mismatch', 1;
IF EXISTS (SELECT 1 FROM KoraOperations.kora.open_order_monthly_snapshot b JOIN KoraOperations.kora.order_lines l ON b.order_line_id=l.order_line_id JOIN KoraOperations.kora.orders o ON l.order_id=o.order_id OUTER APPLY (SELECT SUM(s.quantity) q FROM KoraOperations.kora.sales_lines s WHERE s.order_line_id=l.order_line_id AND s.sale_date<=b.snapshot_date) f WHERE b.open_quantity<>l.quantity-COALESCE(f.q,0) OR o.order_date>b.snapshot_date OR (o.cancelled_date IS NOT NULL AND o.cancelled_date<=b.snapshot_date)) THROW 51009, 'Open-order snapshot mismatch', 1;
SELECT 'PASS - load and reconciliation checks completed' AS validation_result;

USE KoraOperations;
GO
IF EXISTS(SELECT 1 FROM kora.invoices i OUTER APPLY(SELECT SUM(sales_value_ngn) amt FROM kora.sales_lines s WHERE s.delivery_id=i.delivery_id) s WHERE i.invoice_amount_ngn<>COALESCE(s.amt,0)) THROW 51700,'Invoice sales mismatch',1;
IF EXISTS(SELECT 1 FROM kora.cash_receipts r OUTER APPLY(SELECT SUM(allocated_amount_ngn) amt FROM kora.payment_allocations a WHERE a.receipt_id=r.receipt_id) a WHERE r.amount_ngn<>COALESCE(a.amt,0)) THROW 51700,'Receipt allocation mismatch',1;
IF EXISTS(SELECT 1 FROM kora.payment_allocations a JOIN kora.cash_receipts r ON a.receipt_id=r.receipt_id JOIN kora.invoices i ON a.invoice_id=i.invoice_id WHERE r.customer_id<>i.customer_id OR r.receipt_date<i.invoice_date) THROW 51700,'Invalid receipt allocation',1;
IF EXISTS(SELECT 1 FROM kora.credit_notes c JOIN kora.returns r ON c.return_id=r.return_id WHERE c.credit_amount_ngn<>r.refund_ngn OR c.credit_date<>r.return_date) THROW 51700,'Return credit mismatch',1;
IF EXISTS(SELECT 1 FROM kora.goods_receipts r JOIN kora.inventory_movements m ON m.movement_id=r.movement_id WHERE m.movement_type<>'Receipt' OR m.quantity_change<>r.received_quantity OR m.movement_date<>r.received_date) THROW 51700,'Goods receipt stock mismatch',1;
IF EXISTS(SELECT l.purchase_order_line_id FROM kora.purchase_order_lines l JOIN kora.goods_receipts r ON r.purchase_order_line_id=l.purchase_order_line_id GROUP BY l.purchase_order_line_id,l.ordered_quantity HAVING SUM(r.received_quantity)>l.ordered_quantity) THROW 51700,'Supplier overreceipt',1;
USE KoraPeople;
GO
IF EXISTS(SELECT 1 FROM kora.promotion_candidates c JOIN kora.assignments a ON c.assignment_id_at_assessment=a.assignment_id JOIN kora.employment_spells s ON s.spell_id=a.spell_id JOIN kora.promotion_rounds r ON r.round_id=c.round_id WHERE c.employee_id<>s.employee_id OR r.decision_date<a.effective_start OR r.decision_date>=COALESCE(a.effective_end,'20260101')) THROW 51700,'Invalid assessment assignment',1;
SELECT 'PASS - extended load checks completed' result;
GO
