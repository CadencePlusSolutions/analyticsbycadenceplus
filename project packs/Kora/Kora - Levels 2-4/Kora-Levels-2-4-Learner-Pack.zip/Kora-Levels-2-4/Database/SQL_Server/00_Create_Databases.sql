-- Run on a local SQL Server instance using an account permitted to create databases.
USE master;
GO
IF DB_ID(N'KoraOperations') IS NULL EXEC(N'CREATE DATABASE KoraOperations');
IF DB_ID(N'KoraPeople') IS NULL EXEC(N'CREATE DATABASE KoraPeople');
GO
-- Existing databases are never dropped or reset. KoraStarter is untouched.
