-- Run once after validation. Indexes contain no project solutions.
USE KoraOperations;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_orders_date_branch' AND object_id=OBJECT_ID('kora.orders')) CREATE INDEX IX_orders_date_branch ON kora.orders(order_date,branch_id);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_lines_order' AND object_id=OBJECT_ID('kora.order_lines')) CREATE INDEX IX_lines_order ON kora.order_lines(order_id);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_sales_date_line' AND object_id=OBJECT_ID('kora.sales_lines')) CREATE INDEX IX_sales_date_line ON kora.sales_lines(sale_date,order_line_id);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_stock_date' AND object_id=OBJECT_ID('kora.inventory_movements')) CREATE INDEX IX_stock_date ON kora.inventory_movements(branch_id,product_id,movement_date) INCLUDE(quantity_change);
GO
USE KoraPeople;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_assignment_spell_dates' AND object_id=OBJECT_ID('kora.assignments')) CREATE INDEX IX_assignment_spell_dates ON kora.assignments(spell_id,effective_start,effective_end);
GO
