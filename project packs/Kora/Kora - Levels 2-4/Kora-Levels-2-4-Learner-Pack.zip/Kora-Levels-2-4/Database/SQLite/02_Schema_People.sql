PRAGMA foreign_keys=ON;
CREATE TABLE "dataset_info" (
  "dataset_version" TEXT NOT NULL,
  "start_date" TEXT NOT NULL,
  "cutoff_date" TEXT NOT NULL,
  "currency" TEXT NOT NULL,
  PRIMARY KEY ("dataset_version")
);

CREATE TABLE "months" (
  "snapshot_date" TEXT NOT NULL,
  "month_start" TEXT NOT NULL,
  "calendar_year" INTEGER NOT NULL,
  "month_number" INTEGER NOT NULL,
  PRIMARY KEY ("snapshot_date")
);

CREATE TABLE "branches" (
  "branch_id" TEXT NOT NULL,
  "branch_name" TEXT NOT NULL,
  "region_name" TEXT NOT NULL,
  "city" TEXT NOT NULL,
  PRIMARY KEY ("branch_id")
);

CREATE TABLE "employees" (
  "employee_id" TEXT NOT NULL,
  "employee_name" TEXT NOT NULL,
  "first_hire_date" TEXT NOT NULL,
  PRIMARY KEY ("employee_id")
);

CREATE TABLE "employment_spells" (
  "spell_id" INTEGER NOT NULL,
  "employee_id" TEXT NOT NULL,
  "hire_date" TEXT NOT NULL,
  "termination_date" TEXT NULL,
  "exit_type" TEXT NULL,
  "exit_reason" TEXT NULL,
  PRIMARY KEY ("spell_id"),
  FOREIGN KEY ("employee_id") REFERENCES "employees" ("employee_id"),
  CHECK (termination_date IS NULL OR termination_date > hire_date)
);

CREATE TABLE "assignments" (
  "assignment_id" INTEGER NOT NULL,
  "spell_id" INTEGER NOT NULL,
  "branch_id" TEXT NOT NULL,
  "manager_employee_id" TEXT NULL,
  "role_name" TEXT NOT NULL,
  "grade" INTEGER NOT NULL,
  "annual_salary_ngn" NUMERIC NOT NULL,
  "fte" NUMERIC NOT NULL,
  "effective_start" TEXT NOT NULL,
  "effective_end" TEXT NULL,
  "change_type" TEXT NOT NULL,
  PRIMARY KEY ("assignment_id"),
  FOREIGN KEY ("spell_id") REFERENCES "employment_spells" ("spell_id"),
  FOREIGN KEY ("branch_id") REFERENCES "branches" ("branch_id"),
  FOREIGN KEY ("manager_employee_id") REFERENCES "employees" ("employee_id"),
  CHECK (effective_end IS NULL OR effective_end > effective_start),
  CHECK (fte > 0 AND fte <= 1),
  CHECK (annual_salary_ngn > 0)
);

CREATE TABLE "staff_monthly_snapshot" (
  "snapshot_date" TEXT NOT NULL,
  "employee_id" TEXT NOT NULL,
  "spell_id" INTEGER NOT NULL,
  "assignment_id" INTEGER NOT NULL,
  "branch_id" TEXT NOT NULL,
  "manager_employee_id" TEXT NULL,
  "role_name" TEXT NOT NULL,
  "grade" INTEGER NOT NULL,
  "annual_salary_ngn" NUMERIC NOT NULL,
  "fte" NUMERIC NOT NULL,
  PRIMARY KEY ("snapshot_date", "employee_id"),
  FOREIGN KEY ("snapshot_date") REFERENCES "months" ("snapshot_date"),
  FOREIGN KEY ("employee_id") REFERENCES "employees" ("employee_id"),
  FOREIGN KEY ("spell_id") REFERENCES "employment_spells" ("spell_id"),
  FOREIGN KEY ("assignment_id") REFERENCES "assignments" ("assignment_id"),
  FOREIGN KEY ("branch_id") REFERENCES "branches" ("branch_id"),
  FOREIGN KEY ("manager_employee_id") REFERENCES "employees" ("employee_id")
);

CREATE TABLE "staff_monthly_hours" (
  "snapshot_date" TEXT NOT NULL,
  "assignment_id" INTEGER NOT NULL,
  "scheduled_hours" NUMERIC NOT NULL,
  "absence_hours" NUMERIC NOT NULL,
  "overtime_hours" NUMERIC NOT NULL,
  PRIMARY KEY ("snapshot_date", "assignment_id"),
  FOREIGN KEY ("snapshot_date") REFERENCES "months" ("snapshot_date"),
  FOREIGN KEY ("assignment_id") REFERENCES "assignments" ("assignment_id"),
  CHECK (scheduled_hours >= absence_hours AND absence_hours >= 0),
  CHECK (overtime_hours >= 0)
);

CREATE TABLE "promotion_rounds" (
  "round_id" INTEGER NOT NULL,
  "branch_id" TEXT NOT NULL,
  "decision_date" TEXT NOT NULL,
  "effective_date" TEXT NOT NULL,
  "target_grade" INTEGER NOT NULL,
  "positions" INTEGER NOT NULL,
  "eligibility_policy" TEXT NOT NULL,
  PRIMARY KEY ("round_id"),
  FOREIGN KEY ("branch_id") REFERENCES "branches" ("branch_id")
);

CREATE TABLE "promotion_candidates" (
  "round_id" INTEGER NOT NULL,
  "employee_id" TEXT NOT NULL,
  "assignment_id_at_assessment" INTEGER NOT NULL,
  "eligible" INTEGER NOT NULL,
  "assessment_score" NUMERIC NULL,
  "selected" INTEGER NOT NULL,
  "decision_reason" TEXT NULL,
  PRIMARY KEY ("round_id", "employee_id"),
  FOREIGN KEY ("round_id") REFERENCES "promotion_rounds" ("round_id"),
  FOREIGN KEY ("employee_id") REFERENCES "employees" ("employee_id"),
  FOREIGN KEY ("assignment_id_at_assessment") REFERENCES "assignments" ("assignment_id"),
  CHECK ("eligible" IN (0,1)),
  CHECK ("selected" IN (0,1))
);

CREATE TABLE "grades" (
  "grade" INTEGER NOT NULL,
  "grade_label" TEXT NOT NULL,
  "definition" TEXT NOT NULL,
  PRIMARY KEY ("grade")
);
