"""Validate the ready SQLite database row counts and relational integrity."""
from pathlib import Path
import sqlite3,json
ROOT=Path(__file__).resolve().parents[2]
CONTROL=json.loads((ROOT/'Reference/Load_Control_Totals.json').read_text())
for db in ('KoraOperations','KoraPeople'):
 path=Path(__file__).resolve().parent/(db+'.sqlite')
 if not path.exists():raise SystemExit(f'Missing {path}')
 conn=sqlite3.connect(f'file:{path}?mode=ro',uri=True)
 try:
  for key,entry in CONTROL.items():
   if key.startswith(db+'.') and isinstance(entry,dict) and 'rows' in entry:
    table=key.split('.',1)[1]
    actual=conn.execute('SELECT COUNT(*) FROM "'+table+'"').fetchone()[0]
    assert actual==entry['rows'],(key,actual,entry['rows'])
  assert conn.execute('PRAGMA foreign_key_check').fetchone() is None,db
  assert conn.execute('PRAGMA quick_check').fetchone()[0]=='ok',db
  print(db,'PASS')
 finally:conn.close()
