PRAGMA foreign_keys=ON;
CREATE TABLE "dataset_info" (
  "dataset_version" TEXT NOT NULL,
  "start_date" TEXT NOT NULL,
  "cutoff_date" TEXT NOT NULL,
  "currency" TEXT NOT NULL,
  PRIMARY KEY ("dataset_version")
);

CREATE TABLE "months" (
  "snapshot_date" TEXT NOT NULL,
  "month_start" TEXT NOT NULL,
  "calendar_year" INTEGER NOT NULL,
  "month_number" INTEGER NOT NULL,
  PRIMARY KEY ("snapshot_date")
);

CREATE TABLE "branches" (
  "branch_id" TEXT NOT NULL,
  "branch_name" TEXT NOT NULL,
  "region_name" TEXT NOT NULL,
  "city" TEXT NOT NULL,
  PRIMARY KEY ("branch_id")
);

CREATE TABLE "customers" (
  "customer_id" TEXT NOT NULL,
  "customer_name" TEXT NOT NULL,
  "region_name" TEXT NOT NULL,
  "segment" TEXT NOT NULL,
  PRIMARY KEY ("customer_id")
);

CREATE TABLE "products" (
  "product_id" TEXT NOT NULL,
  "product_name" TEXT NOT NULL,
  "category" TEXT NOT NULL,
  "standard_unit_cost_ngn" NUMERIC NOT NULL,
  PRIMARY KEY ("product_id")
);

CREATE TABLE "orders" (
  "order_id" INTEGER NOT NULL,
  "customer_id" TEXT NOT NULL,
  "branch_id" TEXT NOT NULL,
  "order_date" TEXT NOT NULL,
  "promised_date" TEXT NOT NULL,
  "cancelled_date" TEXT NULL,
  "channel" TEXT NOT NULL,
  "complexity" TEXT NOT NULL,
  "standard_work_hours" NUMERIC NOT NULL,
  PRIMARY KEY ("order_id"),
  FOREIGN KEY ("customer_id") REFERENCES "customers" ("customer_id"),
  FOREIGN KEY ("branch_id") REFERENCES "branches" ("branch_id"),
  CHECK (promised_date >= order_date),
  CHECK (cancelled_date IS NULL OR cancelled_date >= order_date)
);

CREATE TABLE "order_lines" (
  "order_line_id" INTEGER NOT NULL,
  "order_id" INTEGER NOT NULL,
  "product_id" TEXT NOT NULL,
  "quantity" INTEGER NOT NULL,
  "unit_price_ngn" NUMERIC NOT NULL,
  "discount_rate" NUMERIC NOT NULL,
  "net_order_value_ngn" NUMERIC NOT NULL,
  PRIMARY KEY ("order_line_id"),
  FOREIGN KEY ("order_id") REFERENCES "orders" ("order_id"),
  FOREIGN KEY ("product_id") REFERENCES "products" ("product_id"),
  CHECK (quantity > 0),
  CHECK (discount_rate >= 0 AND discount_rate <= 1)
);

CREATE TABLE "deliveries" (
  "delivery_id" INTEGER NOT NULL,
  "order_id" INTEGER NOT NULL,
  "promised_date" TEXT NOT NULL,
  "delivery_date" TEXT NULL,
  "status" TEXT NOT NULL,
  "shipping_cost_ngn" NUMERIC NOT NULL,
  "rework_hours" NUMERIC NOT NULL,
  "complaint_flag" INTEGER NOT NULL,
  PRIMARY KEY ("delivery_id"),
  FOREIGN KEY ("order_id") REFERENCES "orders" ("order_id"),
  CHECK ("complaint_flag" IN (0,1))
);

CREATE TABLE "delivery_lines" (
  "delivery_id" INTEGER NOT NULL,
  "order_line_id" INTEGER NOT NULL,
  "delivered_quantity" INTEGER NOT NULL,
  PRIMARY KEY ("delivery_id", "order_line_id"),
  FOREIGN KEY ("delivery_id") REFERENCES "deliveries" ("delivery_id"),
  FOREIGN KEY ("order_line_id") REFERENCES "order_lines" ("order_line_id"),
  CHECK (delivered_quantity > 0)
);

CREATE TABLE "sales_lines" (
  "sales_line_id" INTEGER NOT NULL,
  "delivery_id" INTEGER NOT NULL,
  "order_line_id" INTEGER NOT NULL,
  "sale_date" TEXT NOT NULL,
  "quantity" INTEGER NOT NULL,
  "sales_value_ngn" NUMERIC NOT NULL,
  "cost_of_goods_ngn" NUMERIC NOT NULL,
  PRIMARY KEY ("sales_line_id"),
  FOREIGN KEY ("delivery_id") REFERENCES "deliveries" ("delivery_id"),
  FOREIGN KEY ("order_line_id") REFERENCES "order_lines" ("order_line_id")
);

CREATE TABLE "returns" (
  "return_id" INTEGER NOT NULL,
  "sales_line_id" INTEGER NOT NULL,
  "return_date" TEXT NOT NULL,
  "quantity" INTEGER NOT NULL,
  "refund_ngn" NUMERIC NOT NULL,
  "recovered_cost_ngn" NUMERIC NOT NULL,
  "restocked" INTEGER NOT NULL,
  "return_reason" TEXT NULL,
  PRIMARY KEY ("return_id"),
  FOREIGN KEY ("sales_line_id") REFERENCES "sales_lines" ("sales_line_id"),
  CHECK ("restocked" IN (0,1))
);

CREATE TABLE "inventory_movements" (
  "movement_id" INTEGER NOT NULL,
  "branch_id" TEXT NOT NULL,
  "product_id" TEXT NOT NULL,
  "movement_date" TEXT NOT NULL,
  "movement_type" TEXT NOT NULL,
  "quantity_change" INTEGER NOT NULL,
  "sales_line_id" INTEGER NULL,
  "return_id" INTEGER NULL,
  PRIMARY KEY ("movement_id"),
  FOREIGN KEY ("branch_id") REFERENCES "branches" ("branch_id"),
  FOREIGN KEY ("product_id") REFERENCES "products" ("product_id"),
  FOREIGN KEY ("sales_line_id") REFERENCES "sales_lines" ("sales_line_id"),
  FOREIGN KEY ("return_id") REFERENCES "returns" ("return_id")
);

CREATE TABLE "inventory_monthly_snapshot" (
  "snapshot_date" TEXT NOT NULL,
  "branch_id" TEXT NOT NULL,
  "product_id" TEXT NOT NULL,
  "on_hand_quantity" INTEGER NOT NULL,
  "stock_value_ngn" NUMERIC NOT NULL,
  PRIMARY KEY ("snapshot_date", "branch_id", "product_id"),
  FOREIGN KEY ("snapshot_date") REFERENCES "months" ("snapshot_date"),
  FOREIGN KEY ("branch_id") REFERENCES "branches" ("branch_id"),
  FOREIGN KEY ("product_id") REFERENCES "products" ("product_id")
);

CREATE TABLE "open_order_monthly_snapshot" (
  "snapshot_date" TEXT NOT NULL,
  "order_line_id" INTEGER NOT NULL,
  "open_quantity" INTEGER NOT NULL,
  "open_value_ngn" NUMERIC NOT NULL,
  PRIMARY KEY ("snapshot_date", "order_line_id"),
  FOREIGN KEY ("snapshot_date") REFERENCES "months" ("snapshot_date"),
  FOREIGN KEY ("order_line_id") REFERENCES "order_lines" ("order_line_id")
);

CREATE TABLE "branch_monthly_resources" (
  "snapshot_date" TEXT NOT NULL,
  "branch_id" TEXT NOT NULL,
  "available_service_hours" NUMERIC NOT NULL,
  "fixed_operating_cost_ngn" NUMERIC NOT NULL,
  "overtime_cost_ngn" NUMERIC NOT NULL,
  "service_budget_ngn" NUMERIC NOT NULL,
  PRIMARY KEY ("snapshot_date", "branch_id"),
  FOREIGN KEY ("snapshot_date") REFERENCES "months" ("snapshot_date"),
  FOREIGN KEY ("branch_id") REFERENCES "branches" ("branch_id")
);

CREATE TABLE "payment_terms" (
  "payment_term_id" TEXT NOT NULL,
  "term_days" INTEGER NOT NULL,
  "description" TEXT NOT NULL,
  PRIMARY KEY ("payment_term_id")
);

CREATE TABLE "invoices" (
  "invoice_id" INTEGER NOT NULL,
  "delivery_id" INTEGER NOT NULL,
  "customer_id" TEXT NOT NULL,
  "branch_id" TEXT NOT NULL,
  "invoice_date" TEXT NOT NULL,
  "due_date" TEXT NOT NULL,
  "payment_term_id" TEXT NOT NULL,
  "invoice_amount_ngn" NUMERIC NOT NULL,
  PRIMARY KEY ("invoice_id"),
  FOREIGN KEY ("delivery_id") REFERENCES "deliveries" ("delivery_id"),
  FOREIGN KEY ("customer_id") REFERENCES "customers" ("customer_id"),
  FOREIGN KEY ("branch_id") REFERENCES "branches" ("branch_id"),
  FOREIGN KEY ("payment_term_id") REFERENCES "payment_terms" ("payment_term_id"),
  CHECK (due_date >= invoice_date),
  CHECK (invoice_amount_ngn > 0)
);

CREATE TABLE "credit_notes" (
  "credit_note_id" INTEGER NOT NULL,
  "invoice_id" INTEGER NOT NULL,
  "return_id" INTEGER NOT NULL,
  "credit_date" TEXT NOT NULL,
  "credit_amount_ngn" NUMERIC NOT NULL,
  PRIMARY KEY ("credit_note_id"),
  FOREIGN KEY ("invoice_id") REFERENCES "invoices" ("invoice_id"),
  FOREIGN KEY ("return_id") REFERENCES "returns" ("return_id"),
  CHECK (credit_amount_ngn > 0)
);

CREATE TABLE "cash_receipts" (
  "receipt_id" INTEGER NOT NULL,
  "customer_id" TEXT NOT NULL,
  "receipt_date" TEXT NOT NULL,
  "amount_ngn" NUMERIC NOT NULL,
  PRIMARY KEY ("receipt_id"),
  FOREIGN KEY ("customer_id") REFERENCES "customers" ("customer_id"),
  CHECK (amount_ngn > 0)
);

CREATE TABLE "payment_allocations" (
  "allocation_id" INTEGER NOT NULL,
  "receipt_id" INTEGER NOT NULL,
  "invoice_id" INTEGER NOT NULL,
  "allocated_amount_ngn" NUMERIC NOT NULL,
  PRIMARY KEY ("allocation_id"),
  FOREIGN KEY ("receipt_id") REFERENCES "cash_receipts" ("receipt_id"),
  FOREIGN KEY ("invoice_id") REFERENCES "invoices" ("invoice_id"),
  CHECK (allocated_amount_ngn > 0)
);

CREATE TABLE "cash_refunds" (
  "cash_refund_id" INTEGER NOT NULL,
  "credit_note_id" INTEGER NOT NULL,
  "refund_date" TEXT NOT NULL,
  "amount_ngn" NUMERIC NOT NULL,
  PRIMARY KEY ("cash_refund_id"),
  FOREIGN KEY ("credit_note_id") REFERENCES "credit_notes" ("credit_note_id"),
  CHECK (amount_ngn > 0)
);

CREATE TABLE "operating_expenses" (
  "expense_id" INTEGER NOT NULL,
  "branch_id" TEXT NOT NULL,
  "recognition_date" TEXT NOT NULL,
  "expense_category" TEXT NOT NULL,
  "amount_ngn" NUMERIC NOT NULL,
  "delivery_id" INTEGER NULL,
  PRIMARY KEY ("expense_id"),
  FOREIGN KEY ("branch_id") REFERENCES "branches" ("branch_id"),
  FOREIGN KEY ("delivery_id") REFERENCES "deliveries" ("delivery_id"),
  CHECK (amount_ngn >= 0)
);

CREATE TABLE "monthly_budgets" (
  "snapshot_date" TEXT NOT NULL,
  "branch_id" TEXT NOT NULL,
  "approved_date" TEXT NOT NULL,
  "budget_net_sales_ngn" NUMERIC NOT NULL,
  "budget_net_cogs_ngn" NUMERIC NOT NULL,
  "budget_operating_expenses_ngn" NUMERIC NOT NULL,
  PRIMARY KEY ("snapshot_date", "branch_id"),
  FOREIGN KEY ("snapshot_date") REFERENCES "months" ("snapshot_date"),
  FOREIGN KEY ("branch_id") REFERENCES "branches" ("branch_id")
);

CREATE TABLE "receivables_monthly_snapshot" (
  "snapshot_date" TEXT NOT NULL,
  "invoice_id" INTEGER NOT NULL,
  "balance_ngn" NUMERIC NOT NULL,
  "days_past_due" INTEGER NOT NULL,
  PRIMARY KEY ("snapshot_date", "invoice_id"),
  FOREIGN KEY ("snapshot_date") REFERENCES "months" ("snapshot_date"),
  FOREIGN KEY ("invoice_id") REFERENCES "invoices" ("invoice_id")
);

CREATE TABLE "suppliers" (
  "supplier_id" TEXT NOT NULL,
  "supplier_name" TEXT NOT NULL,
  "standard_lead_days" INTEGER NOT NULL,
  PRIMARY KEY ("supplier_id")
);

CREATE TABLE "purchase_orders" (
  "purchase_order_id" INTEGER NOT NULL,
  "supplier_id" TEXT NOT NULL,
  "branch_id" TEXT NOT NULL,
  "ordered_date" TEXT NOT NULL,
  "promised_receipt_date" TEXT NOT NULL,
  "order_type" TEXT NOT NULL,
  PRIMARY KEY ("purchase_order_id"),
  FOREIGN KEY ("supplier_id") REFERENCES "suppliers" ("supplier_id"),
  FOREIGN KEY ("branch_id") REFERENCES "branches" ("branch_id")
);

CREATE TABLE "purchase_order_lines" (
  "purchase_order_line_id" INTEGER NOT NULL,
  "purchase_order_id" INTEGER NOT NULL,
  "product_id" TEXT NOT NULL,
  "ordered_quantity" INTEGER NOT NULL,
  "unit_cost_ngn" NUMERIC NOT NULL,
  PRIMARY KEY ("purchase_order_line_id"),
  FOREIGN KEY ("purchase_order_id") REFERENCES "purchase_orders" ("purchase_order_id"),
  FOREIGN KEY ("product_id") REFERENCES "products" ("product_id")
);

CREATE TABLE "goods_receipts" (
  "goods_receipt_id" INTEGER NOT NULL,
  "purchase_order_line_id" INTEGER NOT NULL,
  "movement_id" INTEGER NOT NULL,
  "received_date" TEXT NOT NULL,
  "received_quantity" INTEGER NOT NULL,
  PRIMARY KEY ("goods_receipt_id"),
  FOREIGN KEY ("purchase_order_line_id") REFERENCES "purchase_order_lines" ("purchase_order_line_id"),
  FOREIGN KEY ("movement_id") REFERENCES "inventory_movements" ("movement_id")
);

CREATE TABLE "stock_shortage_events" (
  "shortage_id" INTEGER NOT NULL,
  "sales_line_id" INTEGER NOT NULL,
  "branch_id" TEXT NOT NULL,
  "product_id" TEXT NOT NULL,
  "event_date" TEXT NOT NULL,
  "required_quantity" INTEGER NOT NULL,
  "available_quantity" INTEGER NOT NULL,
  "shortage_quantity" INTEGER NOT NULL,
  "emergency_purchase_order_id" INTEGER NOT NULL,
  PRIMARY KEY ("shortage_id"),
  FOREIGN KEY ("sales_line_id") REFERENCES "sales_lines" ("sales_line_id"),
  FOREIGN KEY ("branch_id") REFERENCES "branches" ("branch_id"),
  FOREIGN KEY ("product_id") REFERENCES "products" ("product_id"),
  FOREIGN KEY ("emergency_purchase_order_id") REFERENCES "purchase_orders" ("purchase_order_id")
);
