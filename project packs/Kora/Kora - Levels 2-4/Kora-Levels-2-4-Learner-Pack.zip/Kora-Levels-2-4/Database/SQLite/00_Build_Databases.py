"""Build the two SQLite files from the shared CSV data. Run from any directory."""
from pathlib import Path
import csv, json, sqlite3
ROOT=Path(__file__).resolve().parents[2]
CONTROL=json.loads((ROOT/'Reference/Load_Control_Totals.json').read_text())
HERE=Path(__file__).resolve().parent
for index,db in enumerate(('KoraOperations','KoraPeople'),1):
 target=HERE/(db+'.sqlite')
 if target.exists():raise SystemExit(f'{target} already exists; no data overwritten')
 temp=HERE/(db+'.sqlite.tmp')
 if temp.exists():raise SystemExit(f'{temp} exists from an earlier attempt; inspect it before retrying')
 conn=sqlite3.connect(temp)
 try:
  conn.execute('PRAGMA foreign_keys=ON')
  conn.executescript((HERE/f'0{index}_Schema_{"Operations" if index==1 else "People"}.sql').read_text())
  with conn:
   for key,entry in CONTROL.items():
    if not key.startswith(db+'.') or not isinstance(entry,dict) or 'rows' not in entry:continue
    table=key.split('.',1)[1]
    with (ROOT/'Data'/db/(table+'.csv')).open(newline='',encoding='utf-8-sig') as f:
     reader=csv.reader(f);columns=next(reader)
     sql='INSERT INTO "'+table+'" ('+','.join('"'+c+'"' for c in columns)+') VALUES ('+','.join('?' for _ in columns)+')'
     batch=[];count=0
     for row in reader:
      batch.append([None if x=='' else x for x in row]);count+=1
      if len(batch)==1000:conn.executemany(sql,batch);batch=[]
     if batch:conn.executemany(sql,batch)
     assert count==entry['rows'],(table,count,entry['rows'])
  assert conn.execute('PRAGMA foreign_key_check').fetchone() is None,db
  assert conn.execute('PRAGMA quick_check').fetchone()[0]=='ok',db
  conn.close();temp.rename(target)
  print(db,'ready',target)
 except BaseException:
  conn.close()
  if temp.exists():temp.unlink()
  raise
