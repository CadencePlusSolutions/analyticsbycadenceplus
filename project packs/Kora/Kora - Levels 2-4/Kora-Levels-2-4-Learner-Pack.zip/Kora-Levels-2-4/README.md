# Kora Workplace Supply Ltd. - Free Project Pack

Analyze Financial, People and Operations data.

Start with the [Database Setup Guide](Guides/Kora-Database-Setup-Guide.md), then choose a project below. Each project offers two business problems; choose one. Each guide is available as Markdown, PDF and an editable Word document. Use the data dictionary and schema diagrams for the shared dataset, and the [Think It Through template](Reference/Think-It-Through-Template.pdf) to plan your analysis.

| Project | Business problem A | Business problem B | SQL starter folder |
| --- | --- | --- | --- |
| [Financial Analysis](Guides/Kora-Financial-Analysis-Free-Project-Guide.md) | Profitability and budgets | Receivables and collections | [Finance starter](Projects/Level_2) |
| [People Analysis](Guides/Kora-People-Analysis-Free-Project-Guide.md) | Retention and workforce movement | Progression opportunities | [People starter](Projects/Level_3) |
| [Operations](Guides/Kora-Operations-Free-Project-Guide.md) | Branch service and capacity | Inventory and replenishment | [Operations starter](Projects/Level_4) |

## Install and understand the data

Follow the [Database Setup Guide](Guides/Kora-Database-Setup-Guide.md). Use the [full data dictionary](Reference/Data_Dictionary.md) for database, table and field definitions, the [schema diagrams](Reference/Database_Schema.pdf), and the [complete relationship list](Reference/Relationships.csv).

Operations and Financials is the descriptive name for SQL database `KoraOperations`. It contains the operational and financial data needed by both projects. `KoraPeople` contains internal workforce records. Technical database names are unchanged.

## Dataset and validation

Dataset version 0.2-review: 2022–2025, 40 tables, 630,743 rows, two reporting databases (separate SQLite files). Available for SQL Server, PostgreSQL, MySQL and SQLite. Layout revision 0.3 matches the Project 1 type sizes, includes the CadencePlus logo and uses appropriate -ize spellings throughout authored material.

Automated data reconciliation and reference-view logic checks passed. The SQLite database pair passed row-count, foreign-key and integrity checks. Live SQL Server, PostgreSQL and MySQL loading remains pending; run the supplied validation scripts on those engines before release.

This is a separate four-year synthetic edition; do not append it to Kora Starter or an earlier review extract. Load into an isolated instance or consistently renamed database pair. Loaders do not drop existing databases or overwrite existing kora tables.

## Reuse and credit

You may analyse, modify and publish your SQL, dashboards and findings using this free training dataset with credit to CadencePlus Solutions™. Keep the fictional and synthetic labels. Do not present its values as real customer, employee or market data. Third-party software has its own licences. Reviewer solutions are distributed separately.
