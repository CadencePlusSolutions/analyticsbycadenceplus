# Kora Levels 2–4 | Learner Pack

Kora Workplace Supply Ltd. is fictional. This pack includes four years of synthetic data (2022–2025) for three projects: Financial Analysis, People Analysis and Operations. Choose one of the two business problems in each project guide.

## Start here

1. Read `Guides/Kora-Database-Setup-Guide.pdf` and use the loader for SQL Server, PostgreSQL, MySQL or SQLite in `Database/`.
2. Choose a project from the PDF guides in `Guides/`.
3. Consult the [online data dictionary](https://github.com/CadencePlusSolutions/analyticsbycadenceplus/blob/main/project%20packs/Kora/Kora%20-%20Levels%202-4/Reference/Data_Dictionary.md) for field definitions. It is available in the repository and is not included in this ZIP.
4. Use `Reference/Database_Schema.pdf` for the two schema diagrams and `Reference/Think-It-Through-Template.pdf` to plan your analysis.

The ZIP has data CSVs, database loaders, the PDF guides and the reference PDFs. The SQLite loader builds both databases from the CSVs; it needs `Reference/Load_Control_Totals.json`, which is included solely for loading and validation. The Kora Starter dataset is separate: do not append this data to it. Live loading on SQL Server, PostgreSQL and MySQL still needs local validation.

## Reuse and credit

You may analyse, modify and publish your SQL, dashboards and findings using this free training dataset with credit to CadencePlus Solutions™. Keep the fictional and synthetic labels. Do not present its values as real customer, employee or market data. Third-party software has its own licences.
