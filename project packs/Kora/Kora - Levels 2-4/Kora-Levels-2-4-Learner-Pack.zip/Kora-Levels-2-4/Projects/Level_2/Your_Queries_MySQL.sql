-- Kora Level 2: choose one business problem (A or B).
-- Database: KoraOperations. Required reusable objects: vw_MonthlyFinancial, usp_FinancialSummary, usp_ReceivablesAging.
-- Match the inputs, output columns, validation and boundary cases in the project guide.
-- Use the supplied date cutoff (2025-12-31); do not use the current date.
USE `KoraOperations`;
-- Implement the required view and/or stored procedure here.
-- For a procedure, set a custom client delimiter around CREATE PROCEDURE.
-- Validate parameters and SIGNAL SQLSTATE '45000' for invalid inputs.
-- Include normal, boundary and invalid-input CALL tests below.
