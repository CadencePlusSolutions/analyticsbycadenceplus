-- Kora Level 2: individual submission. Pick one business problem (A or B).
USE KoraOperations;
GO
-- 1. Ask the question and frame the task for your chosen problem.
-- 2. Gather and validate data: grain, dates, keys, missing values, control totals.
-- 3. Build the reusable objects for your chosen problem with CREATE OR ALTER.
--    A: vw_MonthlyFinancial; usp_FinancialSummary
--    B: usp_ReceivablesAging
-- 4. Explore and analyze your chosen problem.
-- 5. Challenge reasoning: alternative explanations and sensitivity tests.
-- 6. Act and explain: recommendations linked to evidence and review measures.
-- Include executable normal, boundary and invalid-input test calls.
