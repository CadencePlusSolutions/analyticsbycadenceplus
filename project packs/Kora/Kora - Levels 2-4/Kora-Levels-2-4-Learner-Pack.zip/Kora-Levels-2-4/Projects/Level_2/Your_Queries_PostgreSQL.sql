-- Kora Level 2: choose one business problem (A or B).
-- Database: KoraOperations. Required reusable objects: vw_MonthlyFinancial, usp_FinancialSummary, usp_ReceivablesAging.
-- Match the inputs, output columns, validation and boundary cases in the project guide.
-- Use the supplied date cutoff (2025-12-31); do not use the current date.
-- Connect to the database above. Tables live in schema kora.
SET search_path TO kora, public;
-- Implement the required reusable view and/or parameterized function here.
-- CREATE OR REPLACE FUNCTION kora.your_function(...) RETURNS TABLE (...)
-- LANGUAGE plpgsql AS $$ BEGIN ... END $$;
-- Include normal, boundary and invalid-input test calls below.
