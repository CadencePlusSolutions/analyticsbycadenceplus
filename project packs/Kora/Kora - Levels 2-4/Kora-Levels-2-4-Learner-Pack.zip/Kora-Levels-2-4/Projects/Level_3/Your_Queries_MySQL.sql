-- Kora Level 3: choose one business problem (A or B).
-- Database: KoraPeople. Required reusable objects: usp_StaffMovement, vw_EmployeeJourney, usp_EmployeeJourney.
-- Match the inputs, output columns, validation and boundary cases in the project guide.
-- Use the supplied date cutoff (2025-12-31); do not use the current date.
USE `KoraPeople`;
-- Implement the required view and/or stored procedure here.
-- For a procedure, set a custom client delimiter around CREATE PROCEDURE.
-- Validate parameters and SIGNAL SQLSTATE '45000' for invalid inputs.
-- Include normal, boundary and invalid-input CALL tests below.
